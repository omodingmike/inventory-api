<?php

    namespace App\Http\Controllers\inventory;

    use App\Models\inventory\Product;
    use App\Models\inventory\Sale;
    use App\Models\inventory\User;
    use Illuminate\Http\Request;
    use Illuminate\Http\Response;
    use Illuminate\Support\Carbon;

    class RevenueController extends Controller
    {
        /**
         * Display a listing of the resource.
         *
         * @return array|string[]
         */
        public function index ( Request $request )
        {
            $user_id      = $request -> user_id;
            $user         = User ::find( $user_id );
            $products_in  = Product ::where( 'user_id' , $user_id ) -> sum( 'quantity' );
            $products_out = 0;
            $startDate    = Carbon ::parse( $request -> query( 'from' ) ) -> startOfDay();
            $endDate      = Carbon ::parse( $request -> query( 'to' ) ) -> endOfDay();

            $revenue = Sale ::where( 'user_id' , $user_id )
                            -> whereBetween( 'created_at' , [ $startDate , $endDate ] )
//                            -> sum( 'grand_total' );
                            -> get();

            $sales = Sale ::with( 'data' )
                          -> where( 'user_id' , $request -> user_id )
                          -> get();
            foreach ( $sales as $sale ) {
                foreach ( $sale -> data as $item ) {
                    $products_out += $item -> quantity;
                }
            }

            if ( $user ) {
                return [
                    'status'  => 'ok' ,
                    'message' => 'success' ,
                    'data'    => [
                        'products_in'  => (int) $products_in ,
                        'products_out' => $products_out ,
                        'revenue'      => $revenue
                    ]
                ];
            } else {
                return [
                    'status'  => 'failed' ,
                    'message' => 'User not found'
                ];
            }
        }

        /**
         * Store a newly created resource in storage.
         *
         * @param Request $request
         * @return Response
         */
        public function store ( Request $request )
        {
            //
        }

        /**
         * Display the specified resource.
         *
         * @param int $id
         * @return Response
         */
        public function show ( $id )
        {
            //
        }

        /**
         * Update the specified resource in storage.
         *
         * @param Request $request
         * @param int     $id
         * @return Response
         */
        public function update ( Request $request , $id )
        {
            //
        }

        /**
         * Remove the specified resource from storage.
         *
         * @param int $id
         * @return Response
         */
        public function destroy ( $id )
        {
            //
        }
    }
