<?php

    namespace App\Http\Controllers\inventory;

    use App\Models\inventory\Contact;
    use App\Models\inventory\Sale;
    use Exception;
    use Illuminate\Http\Request;

    class ContactController extends Controller
    {
        /**
         * Display a listing of the resource.
         *
         * @return Contact[]
         */
        public function index ( Request $request )
        {
            $user_id = $request -> user_id;
            try {
                $sales = Sale ::with( 'data' )
                              -> where( 'user_id' , $request -> user_id )
                              -> get();

                $data     = [];
                $contacts = Contact ::where( 'user_id' , $user_id ) -> get();
                foreach ( $contacts as $contact ) {
                    $total_products = 0;
                    foreach ( $sales as $sale ) {
                        foreach ( $sale -> data as $item ) {
                            if ( $sale -> contact_id == $contact -> id ) {
                                $total_products += $item -> quantity;
                            }
                        }
                    }
                    $collection = collect( $contact );
                    $collection -> put( 'products' , $total_products );
                    $data[] = $collection;
                }
                return [
                    'status' => '1' ,
                    'data'   => $data
                ];
            }
            catch ( Exception $exception ) {
                return [
                    'status'  => '0' ,
                    'message' => $exception -> getMessage()
                ];
            }
        }

        /**
         * Store a newly created resource in storage.
         *
         * @param Request $request
         * @return string[]
         */
        public function store ( Request $request )
        {
            $contact = Contact ::create( $request -> all() );
            if ( $contact ) {
                return [
                    'status'  => 'ok' ,
                    'message' => 'success'
                ];
            } else {
                return [
                    'status'  => 'failed' ,
                    'message' => 'Contact could not be created'
                ];
            }
        }
    }
