<?php

    namespace App\Http\Controllers\inventory;

    use App\Models\inventory\CartItem;
    use App\Models\inventory\Product;
    use App\Models\inventory\Sale;
    use App\Models\inventory\User;
    use Illuminate\Database\QueryException;
    use Illuminate\Http\Request;
    use Illuminate\Support\Arr;
    use Illuminate\Support\Facades\DB;

    class SaleController extends Controller
    {
        /**
         * Display a listing of the resource.
         *
         * @param Request $request
         * @return array
         */
        public function index ( Request $request )
        {
            $user = User ::find( $request -> user_id );

            if ( $user ) {
                return [
                    'status'  => 'ok' ,
                    'message' => 'success' ,
                    'data'    => $user -> sales
                ];
            } else {
                return [
                    'status'  => 'failed' ,
                    'message' => 'User not found'
                ];
            }
        }

        /**
         * Store a newly created resource in storage.
         *
         * @param Request $request
         * @return string[]
         */
        public function store ( Request $request )
        {
            try {
                DB ::beginTransaction();
                $sale = Sale ::create( [
                    'sale_id'     => 'S' . time() ,
                    'user_id'     => Arr ::get( $request , 'user_id' ) ,
                    'grand_total' => Arr ::get( $request , 'grandTotal' ) ,
                    'contact_id'  => Arr ::get( $request , 'customerID' ) ,
                    'mode'        => Arr ::get( $request , 'payment_mode' )
                ] );

                foreach ( Arr ::get( $request , 'items' ) as $item ) {
                    $item[ 'sale_id' ] = $sale -> id;
                    CartItem ::create( $item );
                    Product ::find( $item -> productID ) -> decrement( 'quantity' , $item -> quantity );
                }
                DB ::commit();
                return [
                    'status'  => '1' ,
                    'message' => 'success'
                ];

            }
            catch ( QueryException $exception ) {
                DB ::rollBack();
                return [
                    'status'  => '0' ,
                    'message' => $exception -> getMessage()
                ];
            }
        }
    }
